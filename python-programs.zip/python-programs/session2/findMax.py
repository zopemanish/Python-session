temp1 = [3,1,2,5,12,4,15,12,54,63,1,100]

maxNo = temp1[0]
for x in temp1:
	if x > maxNo:
		maxNo = x

print maxNo