#!/usr/bin/env python

n = 10
res = 1;
for i in range(1,(n+1)):
    res = res*i

print res
