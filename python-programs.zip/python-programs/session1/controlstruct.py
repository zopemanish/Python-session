#!/usr/bin/python

print "Using while loop "

for i in range(1,10):
	print i

print "Using xrange function"
for i in xrange(1,10):
	print i

print "Using while loop "

i = 1
while i<10:
	print i
	i = i +1