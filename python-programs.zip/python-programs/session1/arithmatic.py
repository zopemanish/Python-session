#!/usr/bin/python
num1 = int(raw_input("Enter the first number : "))
num2 = int(raw_input("Enter the second number : "))
print "Addtion of two numbers is : "+str(num1+num2)
print "Substraction of two numbers is : "+str(num1-num2)
print "Division of two numbers is : "+str(num1/num2)
print "Multiplication of two numbers is : "+str(num1*num2)
print "Mod of two numbers is : "+str(num1%num2)


print "Addtion of two numbers is : ", (num1+num2)
print "Substraction of two numbers is : ", (num1-num2)
print "Division of two numbers is : ", (num1/num2)
print "Multiplication of two numbers is : ", (num1*num2)
print "Mod of two numbers is : ", (num1%num2)
