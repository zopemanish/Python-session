#!/usr/bin/env python

for i in range(1,11):
    for j in range(1,11):
        print "%5d" %(i*j),
    print "\n"